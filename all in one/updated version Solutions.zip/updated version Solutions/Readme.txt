To Review all the Solutions, 
In the index.html file just open the script tag in the body tag 
and write the name of the .js file 

<script src="filename"></script>